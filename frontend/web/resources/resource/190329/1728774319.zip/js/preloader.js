jQuery(window).load(function() {
    "use strict";
    jQuery("#status").fadeOut(350);
    jQuery("#preloader").delay(350).fadeOut(200);
});